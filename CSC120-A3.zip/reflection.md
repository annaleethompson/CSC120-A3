Use this file to record your reflection on this assignment.

- Which classmates did you consult with while working on this assignment?
    While working on this assignment I worked with Teddy the most and she helped me to fix a lot of my loops. I was having a lot of trouble getting one of my loops to generate and output the correct resposnes and she helped me go through the code with me and figure out what the issue was. I also talked a little bit with Alex and Dakota at office hours and talked about how we were planning on addressing certain challenges such as the random generator and exchanging the mirror words. Alex also tried to help me out with some of the VS code problems I was having. 
- Which session(s) of TA / office hours did you attend?
    I attended the Sunday 1-3, Sunday 7-9, and Wednesday 7-9 TA hours as well as the Monday 3-4 office hours.
- What are your initial impressions of Java?
    I think that Java so far is okay. I still definitly need more practice with objecto oriented programming but I think that the syntax hasn't been too bad to learn. 
- Can you draw any conclusion about programming in general from the similarities or the differences between the two languages?
    I think that python is a lot easier to manipulate, but this could also be because I don't know as much about Java yet. 
- What worked, what didn't, what advice would you give someone taking this course in the future?
  I think I did a good job at starting the assignment earlier and at planning before coding. I also spend A LOT of time at tutoring hours wich was very helpful but also very time consuming. In the future, I am going to try to do the majority of my assignments at tutoring hours so that I can get help whenever I get stuck instead of waisting time. For someone taking this course in the future, I would say, plan ahead, start early, and seek help. 
