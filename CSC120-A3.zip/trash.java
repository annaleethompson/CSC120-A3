// import java.util.Scanner;
// import java.util.ArrayList;
// //import java.lang.*;
// import java.util.Random;



// //public class Conversation {
  
//  public static void main(String[] arguments) {
//     // You will start the conversation here.
//     int rounds = 0;
//     int random_num = 0;
//     String random_str = "";
//     String response = ""; // or {}
//     ArrayList<String> random_list = new ArrayList<String>();
//     random_list.add("Hmm, interesting");
//     random_list.add("Tell me more...");
//     random_list.add("That's facinating");
//     random_list.add("How are you feeling about this?");
//     random_list.add("Tell me about it");
//     random_list.add("Nice!");
//     random_list.add("What do you mean by that?");
//     Random r = new Random();
//     //Later: System.out.println(r.nextInt(int))
//    // String first = split[0];
//     //StringBuffer transcript = new StringBuffer(" ");
//     ArrayList<String> transcript = new ArrayList<String>();

//     Scanner userInput = new Scanner(System.in);
//     System.out.println("How many conversation rounds do you want?");
//     rounds = userInput.nextInt();
//     //System.out.print(rounds);
    
//     //Scanner scanner = new Scanner(System.in);
//     System.out.println("Hi there! What's on your mind?\n");
//     //response = scanner.nextLine();
//     transcript.add("Hi there! What's on your mind?\n");

//     //String[] split = response.split(" ");
   
     
//     //System.out.println(response);
//     //System.out.println(split[0]);
    
    
//     String response_change = "";
//     Scanner scanner = new Scanner(System.in);
//     //response = scanner.nextLine();
//     for (int i = 0; i<rounds; i++) {
//       //Scanner scanner = new Scanner(System.in);
//       response = scanner.nextLine();
//       transcript.add(response+"\n");
//       if (response.contains("I") || response.contains("me") || response.contains("you") || response.contains("my") || response.contains("your ") || response.contains("are")) {
//         String[] split = response.split(" ");
//         for (String element : split) {
        
//         //System.out.println(element);
//           if (element.contains("I")) {
//             response_change += "you ";
//           }
//           //System.out.println(response_change);
//           if (element.contains("me")) {
//             response_change += "you ";
//           }
//           if (element.contains("you")) {
//             response_change += "I ";
//           }
//           if (element.contains("my")) {
//             response_change += "your ";
//           }
//           if (element.contains("your")) {
//             response_change += "my ";
//           }
//           if (element.contains("are")) {
//             response_change += "am ";
//           }
//           else {
//             response_change += element+" ";
//           //System.out.println(response_change);
//           }
//         }
//       }
//       else {
//         random_num = r.nextInt(7);
//         random_str = random_list.get(random_num);
//         System.out.println(random_str);
//       }
//     if (response.contains("I") || response.contains("me") || response.contains("you") || response.contains("my") || response.contains("your") || response.contains("are")) {
//       System.out.println(response_change+"?\n");
//       transcript.add(response_change+"?\n");
//     }
//     else {
//       System.out.println(response_change+"\n");
//       transcript.add(response_change+"\n");
//     }
//     response_change = "";
//     if (i< rounds-1) {
//       System.out.println("Anthing else?");
//     }
//     }

//     // } else {
//       //   System.out.println("Goodbye!\n");
//       //   transcript.add("Goodbye");
//     scanner.close();
//     userInput.close();
  
//     System.out.println("Goodbye!\n");
//     // trancript.add("Goodbye!");
//     System.out.println("Transcript:\n"+transcript.toString()
//                          .replace("[", "")
//                          .replace(", ", "\n")
//                          .replace("]", ""));
//   }
// }
    
  
 
//     // for (String element : trans) {
//     //   System.out.print(element+"\n");
  
//   // System.out.println("Goodbye!");
//   // trancript.add("Goodbye!");
//   // System.out.println("Transcript:\n"+transcript.toString()
//   //                        .replace("[", "")
//   //                        .replace(", ", "\n")
//   //                        .replace("]", ""));

//   // scanner.close();
//   // userInput.close();


  
  

// //   public static void main(String[] arguments) {
// //     // You will start the conversation here.
// //     int rounds = 0;
// //     String response = ""; // or {}
// //     ArrayList<String> random_list = new ArrayList<String>();
// //     random_list.add("Hmm, interesting");
// //     random_list.add("Tell me more...");
// //     random_list.add("That's facinating");
// //     random_list.add("How are you feeling about this?");
// //     random_list.add("Tell me about it");
// //     random_list.add("Nice!");
// //     random_list.add("What do you mean by that?");
// //     Random r = new Random();
// //     //Later: System.out.println(r.nextInt(int))
// //    // String first = split[0];
// //     //StringBuffer transcript = new StringBuffer(" ");
// //     ArrayList<String> transcript = new ArrayList<String>();

// //     Scanner userInput = new Scanner(System.in);
// //     System.out.println("How many conversation rounds do you want?");
// //     rounds = userInput.nextInt();
// //     //System.out.print(rounds);
    
// //     //Scanner scanner = new Scanner(System.in);
// //     System.out.println("Hi there! What's on your mind?\n");
// //     //response = scanner.nextLine();
// //     transcript.add("Hi there! What's on your mind?\n");

// //     //String[] split = response.split(" ");
   
     
// //     //System.out.println(response);
// //     //System.out.println(split[0]);
    
    
// //     String response_change = "";
// //     Scanner scanner = new Scanner(System.in);
// //     //response = scanner.nextLine();
// //     for (int i = 0; i<rounds; i++) {
// //       //Scanner scanner = new Scanner(System.in);
// //       response = scanner.nextLine();
// //       transcript.add(response+"/n");
// //       String[] split = response.split(" ");
// //       for (String element : split) {
// //         //System.out.println(element);
// //         if (element.contains("I")) {
// //           response_change += "you ";
// //         }
// //           //System.out.println(response_change);
//         if (element.contains("me")) {
//           response_change += "you ";
//         }
//         if (element.contains("You")) {
//           response_change += "I ";
//         }
//         if (element.contains("my")) {
//           response_change += "yours ";
//         }
//         if (element.contains("your")) {
//           response_change += "my ";
//         }
//         if (element.contains("You")) {
//           response_change += "I ";
//         } else {
//           response_change += element+" ";
//           //System.out.println(response_change);
//         }
//       }
//       System.out.println(response_change+"?\n");
//       transcript.add(response_change+"?\n");
//       response_change = "";
//       if (i< rounds-1) {
//         System.out.println("Anthing else?");
//         transcript.add("Goodbye");
//       }// } else {
//       //   System.out.println("Goodbye!\n");
//       //   transcript.add("Goodbye");
//       }
//     }
 
//     // for (String element : trans) {
//     //   System.out.print(element+"\n");
  
//   System.out.println("Goodbye!");
//   trancript.add("Goodbye!");
//   System.out.println("Transcript:\n"+transcript.toString()
//                          .replace("[", "")
//                          .replace(", ", "\n")
//                          .replace("]", ""));

//   scanner.close();
//   userInput.close();
// }


//scanner.close();
    //   response = userInput.nextLine();
    //   System.out.println(first);
      // for (String str : split); {
      //       System.out.println(split);
      // System.out.print(split[0]);
        // if (split[0] == "I" || split[0] == "i") {
         
          // System.out.println("You");
          // transcript.add("You"+ "\n");
          // System.out.println(transcript);
    
  
    // }
        // if (split[-1] == "Me" || split[-1] == "me"){
        //   System.out.println(split[0:-1], "you");
        //   transcript.add(split[0:-1], "you", "\n");
        // }
        // if (split[0] == "Am" || split[0] == "am") {
        //   System.out.println("Are", split[1:0]);
        //   transcript.add("Are", split[1:0], "\n");
        // }
        // if (split[0] == "You" || split[0] == "you") {
        //   System.out.println("I", split[1:0]);
        //   transcript.add("I", split[1:0], "\n");
        // }
        // if (split[0] == "My" || split[0] == "my") {
        //   System.out.println("Your");
        //   System.out.print(split[1:]);
        //   transcript.add("Your", split[1:0], "\n");
        // }
        // if (split[0] == "Your" || split[0] == "you") {
        //   System.out.println("My", split[1:0]);
        //   transcript.add("My", split[1:0], "\n");
        // }
        // if (self.split[0] = "Are" || split[0] = "are") {
        //   System.out.println("Maybe");
        //   transcript.add("Maybe", "\n")
        // }
        // else: {
        //   System.out.println("Hmm, interesting");
        //   transcript.add("Hmm, interesting");
        // }      
    
      // System.out.println("Goodbye!");
      // transcript.add("Goodbye!");

      // userInput.close(); 

  


