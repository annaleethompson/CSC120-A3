//Filename: computer.py
//Decription: Chatbot written in Java that exchanges mirror works or responds with a random response for the inputed number of conversation rounds. 
//A part of CSC 120-02: Object-Oriented Programming, Smith College Spring 2023, A3: Chatbot
    //Author: Anna-Lee Thompson (@annaleethompson)
    //Date: February 15, 2023

//Imports relevent java classes from the java.util package
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

//Conversation class that creates variables for the number of rounds, a random number, a random string, an arraylist for the random responses, a random number generator, and an arraylist to hold the transcript. This class also contains the code for creating the chatbot conversation using scanners to input numbers and strings from the user. 

public class Conversation {
  
  public static void main(String[] arguments) {
    
    //Assigning variables with initial parameters
    int rounds = 0;
    int random_num = 0;
    String random_str = "";
    String response = ""; // or {}
    ArrayList<String> random_list = new ArrayList<String>();
    //Adding possible random responses to the random_list array list 
    random_list.add("Hmm, interesting");
    random_list.add("Tell me more...");
    random_list.add("That's facinating");
    random_list.add("How are you feeling about this?");
    random_list.add("Tell me about it");
    random_list.add("Nice!");
    random_list.add("What do you mean by that?");
    Random r = new Random();
    
    ArrayList<String> transcript = new ArrayList<String>();
   
    //Asks user for number of rounds using scanner
    Scanner userInput = new Scanner(System.in);
    System.out.println("How many conversation rounds do you want?");
    rounds = userInput.nextInt();
    //Start of the conversation
    System.out.println("Hi there! What's on your mind?\n");
    transcript.add("Hi there! What's on your mind?\n");
    //response_change is created to store each response inputed by the user.
    String response_change = "";
    Scanner scanner = new Scanner(System.in);

    //Repeat for rounds, the number of conversations that the user inputed.
    for (int i = 0; i<rounds; i++) {

      response = scanner.nextLine();
      transcript.add(response+"\n");
      //if the response contains any of the mirror words then the chatbot will exchange the mirror words and repeat the phrase back as a question. If there are no mirror words then the chatbot will output a random response using the random generator created above. All of the responses are saved in the transcript array list to be printed later. 
      if (response.contains("I") || response.contains("me") || response.contains("you") || response.contains("my") || response.contains("your ") || response.contains("are")) {
        String[] split = response.split(" ");
        for (String element : split) {
          if (element.equals("You") || element.equals("you")){
            element = "I ";
            response_change += element;
          }
          else if (element.equals("I") || element.equals("i")){
            element = "you ";
            response_change += element;
          }
          else if (element.equals("Me") || element.equals("me")){
              element = "you ";
              response_change += element;
          }
          else if (element.equals("I") || element.equals("i")){
             element = "your ";
             response_change += element;
          }
          else if (element.equals("My") || element.equals("my")){
             element = "your ";
             response_change += element;
          }
          else if (element.equals("Your") || element.equals("your")){
             element = "my ";
             response_change += element;
          }
          else if (element.equals("I") || element.equals("i")){
             element = "you ";
             response_change += element;
          }
          else {
            System.out.println(element);
            
            response_change += element+" ";
          }
        }
      }
      //Generating random number to use to index out a random response from random_list.
      else {
        random_num = r.nextInt(7);
        random_str = random_list.get(random_num);
        System.out.println(random_str);
      }
    //If a mirror word is in the response it will print a question mark with the the response_change generated.
    if (response.contains("I") || response.contains("me") || response.contains("you") || response.contains("my") || response.contains("your") || response.contains("are")) {
      System.out.println(response_change+"?\n");
      transcript.add(response_change+"?\n");
    }
    else {
      System.out.println(response_change+"\n");
      transcript.add(response_change+"\n");
    }
    response_change = "";
    if (i< rounds-1) {
      System.out.println("Anthing else?");
    }
    }
    //Closes scanners
    scanner.close();
    userInput.close();
    //Prints "Goodbye" and the transcripts reformatted into a strings list.
    System.out.println("Goodbye!\n");
    System.out.println("Transcript:\n"+transcript.toString()
                         .replace("[", "")
                         .replace(", ", "\n")
                         .replace("]", ""));
  }
}
    
 